# -*- coding: utf-8 -*

import util, urllib.request, urllib.parse, urllib.error,urllib.request, xbmcplugin, xbmcaddon, xbmcgui, re, sys, os
import json
ADDON_ID = 'plugin.video.listam3u'
BASEURL = 'https://kodi.listam3u.com/'


__addon__ = xbmcaddon.Addon(id=ADDON_ID)
EMAIL = __addon__.getSetting("email")
PASS = __addon__.getSetting("pass")

tvt = xbmcaddon.Addon()
pDialog = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()

def playAudio(params):
        url = params['audioUrl']
        title = params['station']
        img_src = params['logo']
        #li = xbmcgui.ListItem(label=title, iconImage=img_src, thumbnailImage=img_src)
        li = xbmcgui.ListItem(label=title)
        li.setArt({ 'icon': img_src, 'thumb' : img_src })
        li.setInfo(type='Audio', infoLabels={ "Title": title })
        xbmc.Player().play(item=url, listitem=li)

def search(params):

    searchStr = ''
    keyboard = xbmc.Keyboard(searchStr,'Search')
    keyboard.doModal()

    if (keyboard.isConfirmed() == False):
        return mainMenu()
    searchStr = keyboard.getText().replace(' ','+')  # sometimes you need to replace spaces with + or %20
    if len(searchStr) == 0:
        return mainMenu()
    else:
    
        url = BASEURL + '/search.php?search=' + searchStr
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'KODI - LISTAM3U')
        response = urllib.request.urlopen(req)
        obj_data = json.load(response)

        for s in range(len(obj_data)):
            params = {'play':1,
                      'station':obj_data[s]['stationName'],
                      'audioUrl':obj_data[s]['stationURL'],
                      'logo':obj_data[s]['stationLogo']}
            link = util.makeLink(params)
            name = obj_data[s]['stationName']
            img_src = obj_data[s]['stationLogo']
            util.addMenuItem(name, link, img_src, '', True, None, '')
        
        
        util.endListing()

#Get TV List
def categoryTVList(params):
    category = params['category']
		
    url = BASEURL + 'getTVStations.php?category=' + urllib.parse.quote(category) + '&pass=' + PASS + '&email=' + EMAIL
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)

    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'play':1,
                  'station':obj_data[s]['stationName'],
                  'audioUrl':obj_data[s]['stationURL'],
                  'logo':obj_data[s]['stationLogo'],}
        link = util.makeLink(params)
        name = obj_data[s]['stationName']
        img_src = obj_data[s]['stationLogo']
        epg = obj_data[s]['desc']
        util.addMenuItem(name, link, img_src, '', True, None, '', epg)
        
        
    util.endListing()



#Get TV categories
def getTVCategories():
    url = BASEURL + 'getTVCategories.php'
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'categoryTVList':1,
                  'category':obj_data[s]['categoryName']}
        link = util.makeLink(params)
        name = obj_data[s]['categoryName']
        img_src = obj_data[s]['categoryLogo']
        fan_art = obj_data[s]['categoryFanArt']

        #name = name.decode('utf-8')
        util.addMenuItem(name, link, img_src, '', True, None, fan_art)
        
        
    util.endListing()
			
#Get Series categories
def getSeriesCategories():
    url = BASEURL + 'getSeriesCategories.php'
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)

    param = {'searchSeries':1,'search':0, 'start':0}
    link = util.makeLink(param)
    util.addMenuItem('Szukaj Serialu', link, '', setIcon('search'), True, None, '')
    
    for s in range(len(obj_data)):
        params = {'categorySeriesList':1,
                  'categoryID':obj_data[s]['categoryID']}
        link = util.makeLink(params)
        name = obj_data[s]['categoryName']
        img_src = obj_data[s]['categoryLogo']
        fan_art = obj_data[s]['categoryFanArt']

        #name = name.decode('utf-8')
        util.addMenuItem(name, link, img_src, '', True, None, fan_art)
        
        
    util.endListing()

#Get Series List
def categorySeriesList(params):
    category = params['categoryID']
		
    url = BASEURL + 'getSeries.php?categoryID=' + urllib.parse.quote(category) + '&pass=' + PASS + '&email=' + EMAIL
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)

    obj_data = json.load(response)
    #xbmc.log(msg='Results: ' + json.dumps(obj_data['series']), level=xbmc.LOGINFO)
    for s in range(len(obj_data['series'])):
        params = {'seriesEpisodes':1,
                  'seriesID':obj_data['series'][s]['seriesID'],
                 }
        link = util.makeLink(params)
        name = obj_data['series'][s]['seriesTitle']
        img_src = obj_data['series'][s]['seriesCover']
        plot = obj_data['series'][s]['seriesPlot']
        seriesID = obj_data['series'][s]['seriesID']


        util.addSeriesItem(name, link, plot, img_src, '', True, None, '')
        
        
    util.endListing()

#Get Series Episodes
def seriesEpisodes(params):
    seriesID= params['seriesID']
		
    url = BASEURL + 'getSeriesEpisodes.php?seriesID=' + urllib.parse.quote(seriesID) + '&pass=' + PASS + '&email=' + EMAIL
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)

    obj_data = json.load(response)
    #xbmc.log(msg='Results: ' + json.dumps(obj_data['series']), level=xbmc.LOGINFO)
    for s in range(len(obj_data['episodes'])):
        name = obj_data['episodes'][s]['episodeTitle']
        img_src = obj_data['episodes'][s]['episodeCover']
        plot = obj_data['episodes'][s]['episodePlot']
        url = obj_data['episodes'][s]['episodeURL']
        params = {'play':1,
                  'station':name,
                  'audioUrl':url,
                  'logo':img_src,
                  }
        link = util.makeLink(params)
        
        util.addSeriesItem(name, link, plot, img_src, '', False, None, '')
        
        
    util.endListing()

#Search Series
def searchSeries(params):
    searchStr = params['search']
    if searchStr == '0':
      searchStr = ""
      keyboard = xbmc.Keyboard(searchStr,'Search')
      keyboard.doModal()
      searchStr = keyboard.getText().replace(' ','+')  # sometimes you need to replace spaces with + or %20
    
      if (keyboard.isConfirmed() == False):
        return getSeriesCategories()
    
    
    
    if len(searchStr) == 0:
      return getSeriesCategories()
    
    
    #searchStr = urllib.urlencode(searchStr)
    searchStr = urllib.parse.quote(searchStr)
    url = BASEURL + 'searchSeries.php?q=' + searchStr + "&start=" + params['start'] + '&pass=' + PASS + '&email=' + EMAIL
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)
      
      
    for s in range(len(obj_data['series'])):
      name = obj_data['series'][s]['seriesName']
      img_src = obj_data['series'][s]['seriesCover']
      fan_art = obj_data['series'][s]['seriesFanArt']
      genre = obj_data['series'][s]['seriesGenre'],
      year = obj_data['series'][s]['seriesYear'],
      cast = obj_data['series'][s]['seriesCast'],
      director = obj_data['series'][s]['seriesDirector'],
      series_plot = obj_data['series'][s]['seriesPlot'],
      duration = obj_data['series'][s]['seriesDuration'],
      trailer = obj_data['series'][s]['seriesTrailer'],
      rating = obj_data['series'][s]['seriesRating'],
      #caption, link, icon=None, thumbnail=None, folder=False, duration=None, fanart=None
      params = {'seriesEpisodes':1,
                'seriesID':obj_data['series'][s]['seriesID'],
                }
      link = util.makeLink(params)

      #title, link, icon=None, thumbnail=None, folder=False, genre=None, year=None, cast=None, director=None, plot=None, duration=None, trailer=None, fanart=None):
      util.addSeriesItem(name, link, str(series_plot), img_src, '', True, None, '')

    if obj_data['more']['start'] > 0:
        params = {'searchSeries':1,
                'search':searchStr,
                'start':obj_data['more']['start']}
        link = util.makeLink(params)
        util.addMenuItem('Następne', link, '', setIcon('next'), True, None, '')
    
    util.endListing()

#Show Alpha
def showAlpha():
    param = {'showMoviesByLetter':1, 'letter':'number', 'start':0}
    link = util.makeLink(param)
    util.addMenuItem('#123', link, '', setIcon('letters/1'), True, None, '')
    
    for code in range(ord('A'), ord('Z')+1):
      param = {'showMoviesByLetter':1, 'letter':chr(code), 'start':0}
      link = util.makeLink(param)
      icon = setIcon('letters/' + chr(code));
      util.addMenuItem(chr(code), link, '', icon, True, None, '')
      
    util.endListing()

def showMoviesByLetter(params):
    letter = params['letter']
    start = params['start']
    url = BASEURL + 'getMoviesListByLetter.php?letter=' + urllib.parse.quote(letter) + '&start=' + start + '&pass=' + PASS + '&email=' + EMAIL

    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)
    
    
    for s in range(len(obj_data['movies'])):
        name = obj_data['movies'][s]['movieName']
        url = obj_data['movies'][s]['movieURL']
        img_src = obj_data['movies'][s]['movieCover']
        fan_art = obj_data['movies'][s]['movieFanArt']
        genre = obj_data['movies'][s]['movieGenre'],
        year = obj_data['movies'][s]['movieYear'],
        cast = obj_data['movies'][s]['movieCast'],
        director = obj_data['movies'][s]['movieDirector'],
        plot = obj_data['movies'][s]['moviePlot'],
        duration = obj_data['movies'][s]['movieDuration'],
        trailer = obj_data['movies'][s]['movieTrailer'],
        rating = obj_data['movies'][s]['movieRating'],
        params = {'play':1,
                  'station':name,
                  'audioUrl':url,
                  'logo':img_src,
                  }
        link = util.makeLink(params)
        
        util.addMovieItem(name, link, img_src, '', True, genre, year, cast, director, plot, duration, trailer, None, rating)
    
    if obj_data['more']['start'] != 0:
        params = {'showMoviesByLetter':1,
                  'letter':letter,
                  'start':obj_data['more']['start']}
        link = util.makeLink(params)
        util.addMenuItem('Następne', link, '', setIcon('next'), True, None, '')
    util.endListing()    

      
#Get Movies categories
def getMoviesMain():
    url = BASEURL + 'getMoviesCategories.php'
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)
    
    #param = {'moviesAlpha':1}
    #link = util.makeLink(param)
    #util.addMenuItem('Alfabetycznie', link, '', setIcon('movies'), True, None, '')
    
    
    param = {'searchMovies':1,'search':0, 'start':0}
    link = util.makeLink(param)
    util.addMenuItem('Szukaj Filmu', link, '', setIcon('search'), True, None, '')
    
    #param = {'searchActor':1,'search':0, 'start':0}
    #link = util.makeLink(param)
    #util.addMenuItem('Szukaj Aktora', link, '', setIcon('search'), True, None, '')

        
    for s in range(len(obj_data)):
        params = {'getMoviesByCategory':1,
                  'categoryID':obj_data[s]['categoryID'],
                  'start':0}
        link = util.makeLink(params)
        name = obj_data[s]['categoryName']
        img_src = obj_data[s]['categoryLogo']
        fan_art = obj_data[s]['categoryFanArt']
        util.addMenuItem(name, link, img_src, '', True, None, fan_art)
    
    
        
    util.endListing()

#Get List of Movies by category
def getMoviesByCategory(params):
    #xbmc.executebuiltin('Container.SetViewMode(61)')
    category = params['categoryID']
   
    #xbmc.log(msg='Category: ' + params, level=xbmc.LOGINFO)
    start = params['start']
    url = BASEURL + 'getMoviesByCategory.php?categoryID=' + category + '&start=' + start + '&pass=' + PASS + '&email=' + EMAIL
    xbmc.log(msg='URL: ' + url, level=xbmc.LOGINFO)
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'XBMC - IPTVLIVE')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)
    

        
    for s in range(len(obj_data['movies'])):
        name = obj_data['movies'][s]['movieName']
        url = obj_data['movies'][s]['movieURL']
        img_src = obj_data['movies'][s]['movieCover']
        fan_art = obj_data['movies'][s]['movieFanArt']
        genre = obj_data['movies'][s]['movieGenre'],
        year = obj_data['movies'][s]['movieYear'],
        cast = obj_data['movies'][s]['movieCast'],
        director = obj_data['movies'][s]['movieDirector'],
        plot = obj_data['movies'][s]['moviePlot'],
        duration = obj_data['movies'][s]['movieDuration'],
        trailer = obj_data['movies'][s]['movieTrailer'],
        rating = obj_data['movies'][s]['movieRating'],
        #caption, link, icon=None, thumbnail=None, folder=False, duration=None, fanart=None
        params = {'play':1,
                  'station':name,
                  'audioUrl':url,
                  'logo':img_src,
                  }
        link = util.makeLink(params)
        #title, link, icon=None, thumbnail=None, folder=False, genre=None, year=None, cast=None, director=None, plot=None, duration=None, trailer=None, fanart=None):
        util.addMovieItem(name, link, img_src, '', False, genre, year, cast, director, plot, duration, trailer, None, rating)
    
    if obj_data['more']['start'] != 0:
        params = {'getMoviesByCategory':1,
                  'categoryID':category,
                  'start':obj_data['more']['start']}
        link = util.makeLink(params)
        util.addMenuItem('Następne', link, '', setIcon('next'), True, None, '')
    util.endListing()    
      

def getMoviesByActor(params):
    xbmc.executebuiltin('Container.SetViewMode(61)')
    
    actorID = params['actorID']
    start = params['start']
    url = BASEURL + 'getMoviesByActor.php?actorID=' + actorID + '&start=' + start + '&pass=' + PASS + '&email=' + EMAIL
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)
    

        
    for s in range(len(obj_data['movies'])):
        name = obj_data['movies'][s]['movieName']
        url = obj_data['movies'][s]['movieURL']
        img_src = obj_data['movies'][s]['movieCover']
        fan_art = obj_data['movies'][s]['movieFanArt']
        genre = obj_data['movies'][s]['movieGenre'],
        year = obj_data['movies'][s]['movieYear'],
        cast = obj_data['movies'][s]['movieCast'],
        director = obj_data['movies'][s]['movieDirector'],
        plot = obj_data['movies'][s]['moviePlot'],
        duration = obj_data['movies'][s]['movieDuration'],
        trailer = obj_data['movies'][s]['movieTrailer'],
        rating = obj_data['movies'][s]['movieRating'],
       
        #caption, link, icon=None, thumbnail=None, folder=False, duration=None, fanart=None
        params = {'play':1,
                  'station':name,
                  'audioUrl':url,
                  'logo':img_src,
                  }
        link = util.makeLink(params)
        #title, link, icon=None, thumbnail=None, folder=False, genre=None, year=None, cast=None, director=None, plot=None, duration=None, trailer=None, fanart=None):
        util.addMovieItem(name, link, img_src, '', True, genre, year, cast, director, plot, duration, trailer, None, rating)
    
    if obj_data['more']['start'] != 0:
        params = {'getMoviesByActor':1,
                  'actorID':actorID,
                  'start':obj_data['more']['start']}
        link = util.makeLink(params)
        util.addMenuItem('Następne', link, '', setIcon('next'), True, None, '')
    util.endListing()  
      
      
def searchActor(params):
    searchStr = params['search']
    if searchStr == '0':
      searchStr = ""
      keyboard = xbmc.Keyboard(searchStr,'Search')
      keyboard.doModal()
      searchStr = keyboard.getText().replace(' ','+')  # sometimes you need to replace spaces with + or %20
    
      if (keyboard.isConfirmed() == False):
        return getMoviesCategories()
    
    
    
    if len(searchStr) == 0:
      return getMoviesCategories()
    
    
    url = BASEURL + 'searchActor.php?q=' + searchStr + "&start=" + params['start'] + '&pass=' + PASS + '&email=' + EMAIL
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)
      
      
    for s in range(len(obj_data['actors'])):
      name = obj_data['actors'][s]['actorName']
      photo = obj_data['actors'][s]['actorPhoto']
      actorID = obj_data['actors'][s]['actorID']

      #caption, link, icon=None, thumbnail=None, folder=False, duration=None, fanart=None
      params = {'getMoviesByActor':1,'actorID':actorID, 'start':0}
      link = util.makeLink(params)
      #title, link, icon=None, thumbnail=None, folder=False, genre=None, year=None, cast=None, director=None, plot=None, duration=None, trailer=None, fanart=None):
      util.addMenuItem(name, link, photo, photo, True, None,'')
    
    if obj_data['more']['start'] > 0:
        params = {'searchActor':1,
                'search':searchStr,
                'start':obj_data['more']['start']}
        link = util.makeLink(params)
        util.addMenuItem('Następne', link, '', setIcon('next'), True, None, '')
    
    util.endListing()
      
      
def searchMovies(params):
    searchStr = params['search']
    if searchStr == '0':
      searchStr = ""
      keyboard = xbmc.Keyboard(searchStr,'Search')
      keyboard.doModal()
      searchStr = keyboard.getText().replace(' ','+')  # sometimes you need to replace spaces with + or %20
    
      if (keyboard.isConfirmed() == False):
        return getMoviesCategories()
    
    
    
    if len(searchStr) == 0:
      return getMoviesCategories()
    
    
    #searchStr = urllib.urlencode(searchStr)
    searchStr = urllib.parse.quote(searchStr)
    url = BASEURL + 'searchMovies.php?q=' + searchStr + "&start=" + params['start'] + '&pass=' + PASS + '&email=' + EMAIL
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)
      
      
    for s in range(len(obj_data['movies'])):
      name = obj_data['movies'][s]['movieName']
      url = obj_data['movies'][s]['movieURL']
      img_src = obj_data['movies'][s]['movieCover']
      fan_art = obj_data['movies'][s]['movieFanArt']
      genre = obj_data['movies'][s]['movieGenre'],
      year = obj_data['movies'][s]['movieYear'],
      cast = obj_data['movies'][s]['movieCast'],
      director = obj_data['movies'][s]['movieDirector'],
      plot = obj_data['movies'][s]['moviePlot'],
      duration = obj_data['movies'][s]['movieDuration'],
      trailer = obj_data['movies'][s]['movieTrailer'],
      rating = obj_data['movies'][s]['movieRating'],
      #caption, link, icon=None, thumbnail=None, folder=False, duration=None, fanart=None
      params = {'play':1,
        'station':name,
        'audioUrl':url,
        'logo':img_src,
        }
      link = util.makeLink(params)
      #title, link, icon=None, thumbnail=None, folder=False, genre=None, year=None, cast=None, director=None, plot=None, duration=None, trailer=None, fanart=None):
      util.addMovieItem(name, link, img_src, '', False, genre, year, cast, director, plot, None, trailer, None, rating)
    
    if obj_data['more']['start'] > 0:
        params = {'searchMovies':1,
                'search':searchStr,
                'start':obj_data['more']['start']}
        link = util.makeLink(params)
        util.addMenuItem('Następne', link, '', setIcon('next'), True, None, '')
    
    util.endListing()

def radioMainMenu():
    #ddMenuItem(caption, link, icon=None, thumbnail=None, folder=False, duration=None, fanart=None):
    param = {'buildRadioCategories':1}
    link = util.makeLink(param)
    util.addMenuItem('[COLOR red]Gatunki [/COLOR]', link, '', setIcon('Music_Genres'), True, None, '')
    
    
    url = BASEURL + 'getProviders.php'
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)
    
    for s in range(len(obj_data)):
        params = {'radioProviderStations':1,
                  'provider':obj_data[s]['providerName']}
        link = util.makeLink(params)
        name = obj_data[s]['providerName']
        img_src = obj_data[s]['providerLogo']
        util.addMenuItem(name, link, img_src, '', True, None, '')
    
    param = {'radioSearch':1}
    link = util.makeLink(param)
    util.addMenuItem('[COLOR blue]Szukaj [/COLOR]', link, '', setIcon('Music_Genres'), True, None, '')    
    util.endListing()

#Get main page radio categories
def getRadioCategories():
    url = BASEURL + 'getCategories.php'
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'buildRadioCategories':1,
                  'category':obj_data[s]['categoryName'],
                  'logo':obj_data[s]['categoryLogo']}
        link = util.makeLink(params)
        name = obj_data[s]['categoryName']
        img_src = obj_data[s]['categoryLogo']

        util.addMenuItem(name, link, img_src, '', True, None, '')
    
def buildRadioCategories(params):
    url = BASEURL + 'getCategories.php'
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'radioCategoryList':1,
                  'category':obj_data[s]['categoryName']}
        link = util.makeLink(params)
        name = obj_data[s]['categoryName']
        img_src = obj_data[s]['categoryLogo']
        fan_art = obj_data[s]['categoryFanArt']
        
        name = name.decode('utf-8')
        util.addMenuItem(name, link, img_src, '', True, None, fan_art)
        
        
    util.endListing()

def radioCategoryList(params):
    category = params['category']
    url = BASEURL + 'getRadioStations.php?category=' + urllib.parse.quote(category)
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'play':1,
                  'station':obj_data[s]['stationName'],
                  'audioUrl':obj_data[s]['stationURL'],
                  'logo':obj_data[s]['stationLogo']}
        link = util.makeLink(params)
        name = obj_data[s]['stationName']
        img_src = obj_data[s]['stationLogo']
    
        util.addMenuItem(name, link, img_src, '', True, None, '')
        
        
    util.endListing()

def radioProviderStations(params):
    provider = params['provider'].replace(' ','+')
    url = BASEURL + 'getProviderStations.php?provider=' + provider
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'KODI - LISTAM3U')
    response = urllib.request.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'play':1,
                  'station':obj_data[s]['stationName'],
                  'audioUrl':obj_data[s]['stationURL'],
                  'logo':obj_data[s]['stationLogo']}
        link = util.makeLink(params)
        name = obj_data[s]['stationName']
        img_src = obj_data[s]['stationLogo']
        util.addMenuItem(name, link, img_src, '', True, None, '')
        
        
    util.endListing()

def radioSearch(params):
    searchStr = ''
    keyboard = xbmc.Keyboard(searchStr,'Search')
    keyboard.doModal()

    if (keyboard.isConfirmed() == False):
        return mainMenu()
    searchStr = keyboard.getText().replace(' ','+')  # sometimes you need to replace spaces with + or %20
    if len(searchStr) == 0:
        return mainMenu()
    else:
    
        url = BASEURL + 'radioSearch.php?search=' + searchStr
        req = urllib.request.urlopen(url)
        #req.add_header('User-Agent', 'KODI - LISTAM3U')
        response = urllib.request.urlopen(req)
        obj_data = json.load(response)

        for s in range(len(obj_data)):
            params = {'play':1,
                      'station':obj_data[s]['stationName'],
                      'audioUrl':obj_data[s]['stationURL'],
                      'logo':obj_data[s]['stationLogo']}
            link = util.makeLink(params)
            name = obj_data[s]['stationName']
            img_src = obj_data[s]['stationLogo']
            util.addMenuItem(name, link, img_src, '', True, None, '')
        
        
        util.endListing()
    
def percentage(part, whole):
  return 100 * int(part)/int(whole)

def checkVersion():
  url = BASEURL + 'version.php' 
  req = urllib.request.urlopen(url)
  #req.add_header('User-Agent', 'KODI - LISTA M3U')
  from urllib.request import urlopen
  response = urlopen(url)
  obj_data = json.load(response)
  
  addon_version = __addon__.getAddonInfo("version")
  version = obj_data['version'][0]['version']
  
  if addon_version < version:
    dialog.ok(" Używasz starej wersji wtyczki", " Odwiedź http://listam3u.com aby pobrać nową wersje wtyczki ")
    
#Determine Icon path
def setIcon(icon):
        return os.path.join(tvt.getAddonInfo('path'), "images/") + icon + '.png'

#Main Menu Items
def mainMenuItems():
		checkVersion()
		
		param = {'tv':1}
		link = util.makeLink(param)
		util.addMenuItem('Telewizja', link, '', setIcon('tv'), True, None, '')
				
		param = {'movies':1}
		link = util.makeLink(param)
		util.addMenuItem('Filmy', link, '', setIcon('filmy'), True, None, '')
				
				
		param = {'series':1}
		link = util.makeLink(param)
		util.addMenuItem('Seriale', link, '', setIcon('series'), True, None, '')
				
		param = {'radio':1}
		link = util.makeLink(param)
		util.addMenuItem('Radio', link, '', setIcon('radio'), True, None, '')
				
		param = {'options':1}
		link = util.makeLink(param)
		util.addMenuItem('Ustawienia', link, '', setIcon('settings'), True, None, '')
				
		util.endListing()
				
				
#Global Variables    
parameters = util.parseParameters()
CATEGORIES_URL  = BASEURL + 'getCategories.php'




#Main Start of the program
if 'play' in parameters:
    playAudio(parameters)
elif 'categoryTVList' in parameters:
    categoryTVList(parameters)
elif 'tv' in parameters:
    getTVCategories()
elif 'movies' in parameters:
    getMoviesMain()
elif 'getMoviesByCategory' in parameters:
    getMoviesByCategory(parameters)
elif 'getMoviesCategories' in parameters:
    getMoviesCategories()
elif 'showAlpha' in parameters:
    showAlpha()
elif 'searchMovies' in parameters:
    searchMovies(parameters)
elif 'series' in parameters:
    getSeriesCategories()
elif 'searchSeries' in parameters:
    searchSeries(parameters)
elif 'seriesEpisodes' in parameters:
    seriesEpisodes(parameters)
elif 'categorySeriesList' in parameters:
    categorySeriesList(parameters)
elif 'buildRadioCategories' in parameters:
    buildRadioCategories(parameters)
elif 'radio' in parameters:
    radioMainMenu()
elif 'radioCategoryList' in parameters:
    radioCategoryList(parameters)
elif 'radioProviderStations' in parameters:
    radioProviderStations(parameters)
elif 'radioSearch' in parameters:
    radioSearch(parameters)
elif 'options' in parameters:
    __addon__.openSettings()

else:
    mainMenuItems()
