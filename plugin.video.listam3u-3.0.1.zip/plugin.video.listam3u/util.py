# -*- coding: utf-8 -*-

import sys, urllib.request, urllib.parse, urllib.error, urllib.request, re, os
import xbmc, xbmcgui, xbmcaddon, xbmcplugin

ADDON_ID = 'plugin.audio.pl.radio'


def parseParameters(inputString=sys.argv[2]):
    parameters = {}
    p1 = inputString.find('?')
    if p1 >= 0:
        splitParameters = inputString[p1 + 1:].split('&')
        for nameValuePair in splitParameters:
            if (len(nameValuePair) > 0):
                pair = nameValuePair.split('=')
                key = pair[0]
                value = urllib.parse.unquote(urllib.parse.unquote_plus(pair[1]))
                parameters[key] = value
    return parameters


def notify(addonId, message, timeShown=5000):
    addon = xbmcaddon.Addon(addonId)
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % (addon.getAddonInfo('name'), message, timeShown, addon.getAddonInfo('icon')))


def showError(addonId, errorMessage):
    notify(addonId, errorMessage)
    xbmc.log(errorMessage, xbmc.LOGERROR)

    
def makeLink(params, baseUrl=sys.argv[0]):
    return baseUrl + '?' + urllib.parse.urlencode(dict([k.encode('utf-8'),str(v).encode('utf-8')] for k,v in list(params.items())))

#Extract video links from the playlist

def addMenuItem(caption, link, icon=None, thumbnail=None, folder=False, duration=None, fanart=None, epg=None):
    if duration != None:
        duration = int(duration)/60
    #li.setArt({'icon':addon.getAddonInfo("path") + '/resources/media/refresh.png'})
    listItem = xbmcgui.ListItem(str(caption))
    listItem.setLabel(str(caption))
    listItem.setArt({ 'icon': icon, 'thumb' : thumbnail })
    listItem.setInfo(type="Video", infoLabels={ "Title": caption, "Duration": duration, "Plot": epg})
    
   # if len(fanart) != 0:
   #     listItem.setProperty("Fanart_Image", fanart)
    
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=link, listitem=listItem, isFolder=folder)

def addSeriesItem(title, link, plot, icon=None, thumbnail=None, folder=False, duration=None, fanart=None):
    if duration != None:
        duration = int(duration)/60
    #li.setArt({'icon':addon.getAddonInfo("path") + '/resources/media/refresh.png'})
    listItem = xbmcgui.ListItem(str(title))
    listItem.setLabel(str(title))
    listItem.setArt({ 'icon': icon, 'thumb' : thumbnail })
    listItem.setInfo(type="Video", infoLabels={ "Title": title, "Plot": plot })
   # if len(fanart) != 0:
   #     listItem.setProperty("Fanart_Image", fanart)
    
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=link, listitem=listItem, isFolder=folder)

def addSeriesEpisodes(title, link, icon=None, thumbnail=None, folder=False, genre=None, year=None, cast=None, director=None, plot=None, duration=None, trailer=None, fanart=None, rating=None):
    #xbmc.executebuiltin('Container.SetViewMode(50)')
 
    if duration != None:
        duration = duration[0]
        
  
    listItem = xbmcgui.ListItem(str(title))
    listItem.setArt({ 'icon': icon, 'thumb' : thumbnail })
    #ListItem.setInfo(type='video', infoLabels={'title': title, 'genre': genre, 'year': year, 'castandrole':cast, 'plot':plot})
   #listItem.setInfo(type='video', infoLabels={'title': title, 'genre': genre, 'year': year, 'cast': cast, 'director': director, 'plot': plot, 'duration': duration, 'trailer': trailer })
    #liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
    
def addMovieItem(title, link, icon=None, thumbnail=None, folder=False, genre=None, year=None, cast=None, director=None, plot=None, duration=None, trailer=None, fanart=None, rating=None):
    #xbmc.executebuiltin('Container.SetViewMode(50)')
 
    if duration != None:
        duration = duration[0]
        
  
    listItem = xbmcgui.ListItem(str(title))
    listItem.setArt({ 'icon': icon, 'thumb' : thumbnail })
    #ListItem.setInfo(type='video', infoLabels={'title': title, 'genre': genre, 'year': year, 'castandrole':cast, 'plot':plot})
   #listItem.setInfo(type='video', infoLabels={'title': title, 'genre': genre, 'year': year, 'cast': cast, 'director': director, 'plot': plot, 'duration': duration, 'trailer': trailer })
    #liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
   
    print((trailer[0]))
    listItem.setInfo( type='video', infoLabels={'title': title, 'year': year[0], 'plotoutline': plot[0], 'trailer': trailer[0], 'duration':duration, 'castandrole':cast, 'plot': plot[0], 'genre': genre[0], 'rating':rating[0]} )
    if fanart != None:
        listItem.setProperty("Fanart_Image", fanart)
    
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=link, listitem=listItem, isFolder=folder)

def endListing():
    """
    Signals the end of the menu listing
    """
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
    



