# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
#import json
#import random
#import time
#from resources.lib import jsunpack
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.polstreamLive')

mode = addon.getSetting('mode')
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0'
baseurl='http://polstream.live/'

def build_url(query):
    return base_url + '?' + urlencode(query)

def tvList():
    hea={
        'User-Agent':UA,
        'Referer':baseurl
    }
    url='http://polstream.live/pl5.txt'
    channels=[]
    resp=requests.get(url, headers=hea).json()
    for r in resp:
        if r['title']!='Seriale i Programy TV':
            for c in r['folder'] :
                tit=c['title'].encode("latin_1").decode("utf_8")
                channels.append([tit,c['file']])

    for c in channels:
        li=xbmcgui.ListItem(c[0])
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': c[0],'sorttitle': c[0],'plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultTVShows.png', 'fanart': ''})
        url = build_url({'mode':'playSource','link':c[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_TITLE)

def playSource(u):
    #print(u)
    url_stream=u+'|Referer='+baseurl+'&User-Agent='+UA
   
    print(url_stream)
    
    play_item = xbmcgui.ListItem(path=url_stream)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

mode = params.get('mode', None)

if not mode:
    tvList()
else:
        
    if mode=='playSource':
        link=params.get('link')
        playSource(link)
