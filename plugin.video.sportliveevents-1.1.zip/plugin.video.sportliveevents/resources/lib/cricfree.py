# -*- coding: UTF-8 -*-

import sys,re, ast 
import six
from six.moves import urllib_parse

import requests
from requests.compat import urlparse

import datetime
import time


from resources.lib.brotlipython import brotlidec
from resources.lib.cmf3 import parseDOM

sess = requests.Session()


UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:100.0) Gecko/20100101 Firefox/100.0'

main_url = 'https://en.cricfree.io/'
headers = {
    'user-agent': UA,}

def resp_text(resp):
    """Return decoded response text."""
    if resp and resp.headers.get('content-encoding') == 'br':
        out = []
        # terrible implementation but it's pure Python
        return brotlidec(resp.content, out).decode('utf-8')
    response_content = resp.text

    return response_content.replace("\'",'"')
    
    
def request_sess(url, method='get', data={}, headers={}, result=True, json=False, allow=True , json_data = False):
    if method == 'get':
        resp = sess.get(url, headers=headers, timeout=15, verify=False, allow_redirects=allow)
        
    elif method == 'post':
        if json_data:
            resp = sess.post(url, headers=headers, json=data, timeout=15, verify=False, allow_redirects=allow)
        else:
            resp = sess.post(url, headers=headers, data=data, timeout=15, verify=False, allow_redirects=allow)

    if result:
        return resp.json() if json else resp_text(resp)
    else:
        return resp




def get_delta():

    local = datetime.datetime.now()
    utc =  datetime.datetime.utcnow()
    delta = (int((local - utc).days * 86400 + round((local - utc).seconds, -1)))/3600
    return delta
    
def getRealTime(godzina):

    delta = get_delta()
    try:
        date_time_obj=datetime.datetime.strptime(godzina, '%H:%M')+ datetime.timedelta(hours=-1)
    except TypeError:
        date_time_obj=datetime.datetime(*(time.strptime(godzina, '%H:%M')[0:6]))+ datetime.timedelta(hours=-1)
    date_time_obj = date_time_obj+ datetime.timedelta(hours=int(delta))

    return date_time_obj.strftime("%H:%M")
        
def ListMenu():
    return [{'title':'Channels','href':main_url,'image':'x','plot':'Cricfree - 24/7', 'mode':'listchannels:cric'}, {'title':'Schedule','href':main_url,'image':'x','plot':'Cricfree - schedule', 'mode':'listschedule:cric'}]

def ListSchedule(url):
    zz=''
    out=[]
    html = request_sess(main_url, 'get', headers=headers)

    result = parseDOM(html,'article')[0]
    tables = parseDOM(result,'table')
    for table in tables:
        day = parseDOM(table,'th')[0]
        day = '[B]................[COLOR khaki]'+day+'[/COLOR]................[/B]'
        out.append({'title':day,'href':day,'empty':'true'})
        links = parseDOM(table,'tr', attrs={'id': "schedule_.*?"})#[0]
        for link in links:
            czas_data = parseDOM(link,'td', attrs={'class': "time dtstart"})[0]
            czas = parseDOM(czas_data,'span')[0]
            godz = getRealTime(czas)
            
            
            event_data =  parseDOM(link,'td', attrs={'class': "event"})[0]
            title = parseDOM(event_data,'span')[0]
            title = godz + ' - ' +title

            href = parseDOM(event_data,'a', ret="href")[0] 
            if 'live.gif' in link:
                title = title + '[B][COLOR lightgreen]  live [/B][/COLOR]'
            out.append({'title':title,'href':href,'empty':'false', 'mode':'getlinks:cric'})
    return out

def ListChannels():
    out=[]
    html = request_sess('http://cricfree.live/live/sky-sports-premier-league', 'get', headers=headers)    

    for x,y in re.findall('href="([^"]+)" title="([^"]+)"',html,re.DOTALL): 

        out.append({'title':y,'href':x,'mode':'playvid:cric','image':'nic'})
    return out

def GetLinks(url):
    zz=''
    out=[]
    html = request_sess(url, 'get', headers=headers)
    channels =  parseDOM(html,'th', attrs={'class': "play channel_names"})[0]
    hreftitle = re.findall('href\s*=\s*"([^"]+)".*?>([^>]+)<\/a>', channels)
    for href,title in hreftitle:
        out.append({'title':title,'href':href,'empty':'false'})
    return out
    
def GetVid(url):
    zz=''
    out=[]
    url = url.replace('/live/','/live/embed/')
    html = request_sess(url, 'get', headers=headers)
    
    iframe = re.findall('iframe src="([^"]+)"', html,re.DOTALL)[0]# src="
    headers.update({'referer': url})
    html = request_sess(iframe, 'get', headers=headers)
    video_url = None
    if 'castfree.me/embed.' in html:
        fid = re.findall('fid="([^"]+)"', html,re.DOTALL)[0]

        url = 'https://castfree.me/embed.php?player=desktop&live='+fid
        headers.update({'referer': iframe})
        html = request_sess(url, 'get', headers=headers)
        str_url = re.findall('return\((\["h","t.*?\])',html, re.DOTALL+re.IGNORECASE)
        video_url=(''.join(ast.literal_eval(str_url[0]))).replace('\\/','/')
        video_url += '|User-Agent={ua}&Referer=https://castfree.me/'.format(ua=UA)

    return video_url
        
        
        
